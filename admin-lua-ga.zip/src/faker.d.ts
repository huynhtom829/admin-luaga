declare module 'faker'
