declare module 'react-file-base64'
